
import React, { useEffect, useRef } from "react";
import { cn } from "@/lib/utils";
import { Code, Globe, Megaphone, PieChart, Bot, Share2 } from "lucide-react";

interface ServiceCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  index: number;
}

const ServiceCard = ({ icon, title, description, index }: ServiceCardProps) => {
  const cardRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("animate-fade-in");
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.1 }
    );
    
    if (cardRef.current) {
      observer.observe(cardRef.current);
    }
    
    return () => {
      if (cardRef.current) {
        observer.unobserve(cardRef.current);
      }
    };
  }, []);
  
  return (
    <div 
      ref={cardRef}
      className={cn(
        "feature-card glass-card opacity-0 p-5 sm:p-7 border border-gray-100",
        "hover:border-vezzi-400/50 hover:shadow-lg",
        "transition-all duration-300"
      )}
      style={{ animationDelay: `${0.1 * index}s` }}
    >
      <div className="rounded-lg bg-vezzi-500/10 w-12 h-12 sm:w-14 sm:h-14 flex items-center justify-center text-vezzi-500 mb-5 sm:mb-6">
        {icon}
      </div>
      <h3 className="text-lg sm:text-xl font-semibold mb-3 sm:mb-4">{title}</h3>
      <p className="text-gray-600 text-sm sm:text-base">{description}</p>
    </div>
  );
};

const Services = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const elements = entry.target.querySelectorAll(".fade-in-element");
            elements.forEach((el, index) => {
              setTimeout(() => {
                el.classList.add("animate-fade-in");
              }, index * 100);
            });
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.1 }
    );
    
    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }
    
    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current);
      }
    };
  }, []);
  
  return (
    <section className="py-16 sm:py-20 md:py-24 relative bg-white" id="services" ref={sectionRef}>
      <div className="section-container">
        <div className="text-center mb-12 sm:mb-16">
          <div className="pulse-chip mx-auto mb-3 sm:mb-4 opacity-0 fade-in-element" style={{ background: "rgba(255, 69, 0, 0.1)", border: "1px solid rgba(255, 69, 0, 0.3)" }}>
            <span className="text-vezzi-500">Nossos Serviços</span>
          </div>
          <h2 className="section-title mb-3 sm:mb-4 opacity-0 fade-in-element">
            Tecnologia que<br className="hidden sm:block" /> impulsiona seu negócio
          </h2>
          <p className="section-subtitle mx-auto opacity-0 fade-in-element">
            Oferecemos soluções completas em tecnologia para transformar suas ideias em realidade.
          </p>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          <ServiceCard
            icon={<Bot size={28} />}
            title="Automações"
            description="Automatize processos repetitivos e aumente a eficiência operacional com nossas soluções personalizadas de automação para seu negócio."
            index={0}
          />
          <ServiceCard
            icon={<Code size={28} />}
            title="Desenvolvimento Web"
            description="Criamos websites e aplicações web responsivas, performáticas e modernas que convertem visitantes em clientes."
            index={1}
          />
          <ServiceCard
            icon={<Megaphone size={28} />}
            title="Marketing Digital"
            description="Estratégias de marketing digital que ampliam sua presença online e atraem clientes qualificados para o seu negócio."
            index={2}
          />
          <ServiceCard
            icon={<Globe size={28} />}
            title="SEO & Performance"
            description="Otimização para mecanismos de busca e estratégias de desempenho que posicionam seu negócio no topo dos resultados de pesquisa."
            index={3}
          />
          <ServiceCard
            icon={<PieChart size={28} />}
            title="Analytics & Dados"
            description="Análise e visualização de dados para tomada de decisões inteligentes baseadas em informações concretas sobre seu negócio."
            index={4}
          />
          <ServiceCard
            icon={<Share2 size={28} />}
            title="Integração de Sistemas"
            description="Conectamos diferentes plataformas e ferramentas para criar um ecossistema tecnológico eficiente para sua empresa."
            index={5}
          />
        </div>
      </div>
    </section>
  );
};

export default Services;
