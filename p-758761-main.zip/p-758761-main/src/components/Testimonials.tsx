
import React, { useRef } from "react";
import { Star } from "lucide-react";

interface TestimonialProps {
  content: string;
  author: string;
  role: string;
  image?: string;
  rating?: number;
}

const testimonials: TestimonialProps[] = [
  {
    content: "A VezziTech transformou completamente nossos processos internos. A solução de automação desenvolvida por eles economizou horas de trabalho manual e reduziu significativamente nossas taxas de erro.",
    author: "Carlos Silva",
    role: "TechSolve Ltda",
    image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=256&q=80",
    rating: 5
  }, 
  {
    content: "Nossa presença online aumentou exponencialmente após implementarmos a estratégia de marketing digital da VezziTech. Resultados concretos e uma equipe extremamente profissional.",
    author: "Ana Martins",
    role: "Creative Marketing",
    image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=256&q=80",
    rating: 5
  },
  {
    content: "O novo site desenvolvido pela VezziTech é incrível! Rápido, responsivo e com um design que realmente reflete a identidade da nossa marca. As conversões aumentaram em 45%.",
    author: "Roberto Gomes",
    role: "Constrular",
    image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=256&q=80",
    rating: 5
  }, 
  {
    content: "As automações implementadas pela VezziTech ajudaram nossa equipe a se concentrar no que realmente importa. O suporte é excelente e estamos muito satisfeitos com os resultados.",
    author: "Mariana Costa",
    role: "Agência Futuro",
    image: "https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=256&q=80",
    rating: 5
  }
];

const TestimonialCard = ({
  content,
  author,
  role,
  image = "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=256&q=80",
  rating = 5
}: TestimonialProps) => {
  return (
    <div className="bg-white p-6 rounded-xl shadow-md border border-gray-100 transform transition-transform duration-300 hover:-translate-y-2 h-full flex flex-col">
      <div className="flex gap-1 mb-4">
        {Array.from({ length: rating }).map((_, i) => (
          <Star key={i} size={18} className="fill-vezzi-500 text-vezzi-500" />
        ))}
      </div>
      
      <p className="text-gray-700 mb-6 italic flex-grow">{`"${content}"`}</p>
      
      <div className="flex items-center gap-3 mt-auto">
        <img 
          src={image} 
          alt={author} 
          className="w-10 h-10 object-cover rounded-full" 
        />
        <div>
          <div className="font-medium">{author}</div>
          <div className="text-sm text-gray-600">{role}</div>
        </div>
      </div>
    </div>
  );
};

const Testimonials = () => {
  const sectionRef = useRef<HTMLDivElement>(null);

  return (
    <section className="py-16 sm:py-20 md:py-24 bg-gray-50" id="testimonials" ref={sectionRef}>
      <div className="section-container opacity-0 animate-on-scroll">
        <div className="text-center mb-12">
          <div className="pulse-chip mx-auto mb-3 sm:mb-4" style={{ background: "rgba(255, 69, 0, 0.1)", border: "1px solid rgba(255, 69, 0, 0.3)" }}>
            <span className="text-vezzi-500">Depoimentos</span>
          </div>
          <h2 className="section-title mb-3 sm:mb-4">
            O que nossos clientes<br className="hidden sm:block" /> dizem sobre nós
          </h2>
          <p className="section-subtitle mx-auto">
            Veja como nossos serviços têm transformado negócios e feito a diferença para nossos clientes.
          </p>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {testimonials.map((testimonial, index) => (
            <TestimonialCard 
              key={index} 
              content={testimonial.content} 
              author={testimonial.author} 
              role={testimonial.role} 
              image={testimonial.image}
              rating={testimonial.rating}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
