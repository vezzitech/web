
import React, { useEffect, useRef } from "react";
import { Phone, Mail, MapPin, MessageSquare, Send } from "lucide-react";

const Contact = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const elements = entry.target.querySelectorAll(".fade-in-element");
            elements.forEach((el, index) => {
              setTimeout(() => {
                el.classList.add("animate-fade-in");
              }, index * 100);
            });
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.1 }
    );
    
    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }
    
    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current);
      }
    };
  }, []);
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Form submission would go here in a real implementation
    alert("Mensagem enviada! Em breve entraremos em contato.");
  };
  
  return (
    <section className="py-16 sm:py-20 md:py-24 bg-white" id="contact" ref={sectionRef}>
      <div className="section-container">
        <div className="text-center mb-12 sm:mb-16">
          <div className="pulse-chip mx-auto mb-3 sm:mb-4 opacity-0 fade-in-element" style={{ background: "rgba(255, 69, 0, 0.1)", border: "1px solid rgba(255, 69, 0, 0.3)" }}>
            <span className="text-vezzi-500">Entre em Contato</span>
          </div>
          <h2 className="section-title mb-3 sm:mb-4 opacity-0 fade-in-element">
            Vamos conversar sobre<br className="hidden sm:block" /> seu próximo projeto
          </h2>
          <p className="section-subtitle mx-auto opacity-0 fade-in-element">
            Estamos prontos para transformar suas ideias em soluções tecnológicas eficientes.
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-10">
          <div className="lg:col-span-2 space-y-8">
            <div className="opacity-0 fade-in-element">
              <h3 className="text-xl font-semibold mb-4">Informações de Contato</h3>
              <p className="text-gray-600 mb-6">
                Estamos à disposição para atender você. Entre em contato através dos canais abaixo ou preencha o formulário.
              </p>
              
              <div className="space-y-4">
                <a 
                  href="https://wa.me/5548988792949" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="flex items-center gap-3 p-4 border border-gray-200 rounded-lg hover:border-vezzi-500 transition-colors duration-300"
                >
                  <div className="bg-vezzi-500/10 p-2 rounded-full">
                    <Phone size={20} className="text-vezzi-500" />
                  </div>
                  <div>
                    <div className="font-medium">WhatsApp</div>
                    <div className="text-sm text-gray-600">+55 48 98879-2949</div>
                  </div>
                </a>
                
                <a 
                  href="mailto:contato@vezzitech.com.br" 
                  className="flex items-center gap-3 p-4 border border-gray-200 rounded-lg hover:border-vezzi-500 transition-colors duration-300"
                >
                  <div className="bg-vezzi-500/10 p-2 rounded-full">
                    <Mail size={20} className="text-vezzi-500" />
                  </div>
                  <div>
                    <div className="font-medium">Email</div>
                    <div className="text-sm text-gray-600">contato@vezzitech.com.br</div>
                  </div>
                </a>
                
                <div className="flex items-center gap-3 p-4 border border-gray-200 rounded-lg">
                  <div className="bg-vezzi-500/10 p-2 rounded-full">
                    <MapPin size={20} className="text-vezzi-500" />
                  </div>
                  <div>
                    <div className="font-medium">Localização</div>
                    <div className="text-sm text-gray-600">Florianópolis, Santa Catarina - Brasil</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="lg:col-span-3 opacity-0 fade-in-element">
            <div className="bg-white p-6 sm:p-8 rounded-2xl shadow-md border border-gray-100">
              <h3 className="text-xl font-semibold mb-6">Envie uma mensagem</h3>
              
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">Nome</label>
                    <input
                      type="text"
                      id="name"
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-vezzi-500 focus:border-vezzi-500 outline-none transition"
                      placeholder="Seu nome"
                      required
                    />
                  </div>
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                    <input
                      type="email"
                      id="email"
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-vezzi-500 focus:border-vezzi-500 outline-none transition"
                      placeholder="Seu email"
                      required
                    />
                  </div>
                </div>
                
                <div>
                  <label htmlFor="subject" className="block text-sm font-medium text-gray-700 mb-1">Assunto</label>
                  <input
                    type="text"
                    id="subject"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-vezzi-500 focus:border-vezzi-500 outline-none transition"
                    placeholder="Assunto da mensagem"
                    required
                  />
                </div>
                
                <div>
                  <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">Mensagem</label>
                  <textarea
                    id="message"
                    rows={5}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-vezzi-500 focus:border-vezzi-500 outline-none transition resize-none"
                    placeholder="Sua mensagem"
                    required
                  ></textarea>
                </div>
                
                <div>
                  <button
                    type="submit"
                    className="flex items-center justify-center gap-2 w-full py-3 px-6 text-white font-medium rounded-lg transition-colors duration-300"
                    style={{ backgroundColor: '#ff4500' }}
                  >
                    Enviar Mensagem
                    <Send size={18} />
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
        
        <div className="mt-16 opacity-0 fade-in-element">
          <div className="flex items-center justify-center gap-3 p-6 bg-vezzi-50 rounded-xl border border-vezzi-200">
            <MessageSquare size={24} className="text-vezzi-500" />
            <p className="text-gray-700">
              Prefere uma conversa rápida? Entre em contato pelo WhatsApp:{" "}
              <a 
                href="https://wa.me/5548988792949" 
                target="_blank" 
                rel="noopener noreferrer"
                className="font-medium text-vezzi-500 hover:underline"
              >
                +55 48 98879-2949
              </a>
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
