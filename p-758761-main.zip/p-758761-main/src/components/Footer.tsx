import React from "react";
import { Phone, Mail, MapPin, Facebook, Instagram, Linkedin } from "lucide-react";
const Footer = () => {
  return <footer className="bg-gray-900 text-white pt-16 pb-8">
      <div className="section-container">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          <div>
            <img alt="VezziTech Logo" className="h-12 mb-6" src="/lovable-uploads/5d8ade3c-ea75-4355-a95f-d4b12c297dfd.png" />
            <p className="text-gray-400 mb-6">
              Transformando ideias em aplicações inteligentes. Soluções em automação, desenvolvimento web e marketing digital.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center hover:bg-vezzi-500 transition-colors duration-300" aria-label="Facebook">
                <Facebook size={18} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center hover:bg-vezzi-500 transition-colors duration-300" aria-label="Instagram">
                <Instagram size={18} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center hover:bg-vezzi-500 transition-colors duration-300" aria-label="LinkedIn">
                <Linkedin size={18} />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-xl font-semibold mb-6">Serviços</h3>
            <ul className="space-y-3">
              <li>
                <a href="#services" className="text-gray-400 hover:text-vezzi-500 transition-colors duration-300">Automações</a>
              </li>
              <li>
                <a href="#services" className="text-gray-400 hover:text-vezzi-500 transition-colors duration-300">Desenvolvimento Web</a>
              </li>
              <li>
                <a href="#services" className="text-gray-400 hover:text-vezzi-500 transition-colors duration-300">Marketing Digital</a>
              </li>
              <li>
                <a href="#services" className="text-gray-400 hover:text-vezzi-500 transition-colors duration-300">SEO & Performance</a>
              </li>
              <li>
                <a href="#services" className="text-gray-400 hover:text-vezzi-500 transition-colors duration-300">Integração de Sistemas</a>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-xl font-semibold mb-6">Links Rápidos</h3>
            <ul className="space-y-3">
              <li>
                <a href="#" className="text-gray-400 hover:text-vezzi-500 transition-colors duration-300">Início</a>
              </li>
              <li>
                <a href="#about" className="text-gray-400 hover:text-vezzi-500 transition-colors duration-300">Sobre Nós</a>
              </li>
              <li>
                <a href="#services" className="text-gray-400 hover:text-vezzi-500 transition-colors duration-300">Serviços</a>
              </li>
              <li>
                <a href="#contact" className="text-gray-400 hover:text-vezzi-500 transition-colors duration-300">Contato</a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-vezzi-500 transition-colors duration-300">Política de Privacidade</a>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-xl font-semibold mb-6">Contato</h3>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <Phone size={20} className="text-vezzi-500 mt-1 shrink-0" />
                <a href="https://wa.me/5548988792949" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-vezzi-500 transition-colors duration-300">
                  +55 48 98879-2949
                </a>
              </li>
              <li className="flex items-start gap-3">
                <Mail size={20} className="text-vezzi-500 mt-1 shrink-0" />
                <a href="mailto:contato@vezzitech.com.br" className="text-gray-400 hover:text-vezzi-500 transition-colors duration-300">contato@vezzi.tech</a>
              </li>
              <li className="flex items-start gap-3">
                <MapPin size={20} className="text-vezzi-500 mt-1 shrink-0" />
                <span className="text-gray-400">
                  Florianópolis, Santa Catarina - Brasil
                </span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-800 pt-8 text-center">
          <p className="text-gray-500 text-sm">
            &copy; {new Date().getFullYear()} VezziTech. Todos os direitos reservados.
          </p>
        </div>
      </div>
    </footer>;
};
export default Footer;