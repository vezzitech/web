
import React, { useEffect, useRef } from "react";
import { cn } from "@/lib/utils";

const AboutUs = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const elements = entry.target.querySelectorAll(".fade-in-element");
            elements.forEach((el, index) => {
              setTimeout(() => {
                el.classList.add("animate-fade-in");
              }, index * 100);
            });
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.1 }
    );
    
    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }
    
    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current);
      }
    };
  }, []);
  
  return (
    <section className="py-16 sm:py-20 md:py-24 bg-gray-50" id="about" ref={sectionRef}>
      <div className="section-container">
        <div className="flex flex-col lg:flex-row gap-10 lg:gap-16 items-center">
          <div className="w-full lg:w-1/2">
            <div className="relative">
              <div className="absolute -top-4 -left-4 w-24 h-24 md:w-32 md:h-32 rounded-lg bg-vezzi-500/20 -z-10"></div>
              <div className="absolute -bottom-4 -right-4 w-24 h-24 md:w-32 md:h-32 rounded-lg bg-vezzi-500/20 -z-10"></div>
              <img 
                src="https://images.unsplash.com/photo-1488590528505-98d2b5aba04b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80" 
                alt="VezziTech - Equipe trabalhando" 
                className="w-full h-auto rounded-lg shadow-lg opacity-0 fade-in-element object-cover"
              />
            </div>
          </div>
          
          <div className="w-full lg:w-1/2">
            <div className="pulse-chip mb-4 opacity-0 fade-in-element" style={{ background: "rgba(255, 69, 0, 0.1)", border: "1px solid rgba(255, 69, 0, 0.3)" }}>
              <span className="text-vezzi-500">Quem Somos</span>
            </div>
            
            <h2 className="section-title mb-6 opacity-0 fade-in-element">
              VezziTech: Paixão <br />por tecnologia e inovação
            </h2>
            
            <div className="space-y-4 opacity-0 fade-in-element">
              <p className="text-gray-700">
                Na VezziTech, acreditamos no poder da tecnologia para transformar negócios e simplificar processos. Nascemos da paixão por criar soluções tecnológicas que realmente fazem a diferença para nossos clientes.
              </p>
              
              <p className="text-gray-700">
                Nossa equipe é formada por profissionais altamente qualificados e apaixonados por tecnologia, comprometidos em entregar resultados excepcionais. Combinamos expertise técnica com uma profunda compreensão dos desafios de negócio para desenvolver soluções sob medida que impulsionam o crescimento e eficiência.
              </p>
              
              <p className="text-gray-700">
                Trabalhamos em estreita colaboração com nossos clientes, entendendo suas necessidades específicas e oferecendo soluções personalizadas que superam expectativas. Nossa missão é transformar ideias em aplicações inteligentes que geram valor real e resultados mensuráveis.
              </p>
            </div>
            
            <div className="mt-8 grid grid-cols-3 gap-4 opacity-0 fade-in-element">
              <div className="text-center">
                <div className="text-3xl font-bold text-vezzi-500">4+</div>
                <div className="text-sm text-gray-600">Anos de experiência</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-vezzi-500">50+</div>
                <div className="text-sm text-gray-600">Projetos entregues</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-vezzi-500">100%</div>
                <div className="text-sm text-gray-600">Clientes satisfeitos</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutUs;
